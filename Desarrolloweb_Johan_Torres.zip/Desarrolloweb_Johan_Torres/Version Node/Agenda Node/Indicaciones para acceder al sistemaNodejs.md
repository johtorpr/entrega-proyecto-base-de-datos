Agenda NodeJS
1. ejecute la base de datos mongodb
2. Abra la aplicacion e instale los modulos necesaros del package-json
 ------     npm install
2. ejecute la aplicacion ingresando
   ---node index.js
3. ingrese con los usuarios registrados(apareceran en pantalla)
 ---- usuario: admin contraseña: admin
 ---- usuario: adminest contraseña: adminest

 estos usuarios son los que se crean automaticamente se ejecuta la aplicacion y le permitiran loguearse en la palicacion.
