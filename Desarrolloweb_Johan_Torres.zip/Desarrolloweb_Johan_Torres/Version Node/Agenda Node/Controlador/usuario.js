
const Router = require('express').Router(),
      Usuario = require('../modelo/usuario')


  //Metodo obtener un Usuario de sistema
  Router.get('/obtener_usuario', function(req, res) {
    const usuarioID = req.query._id || '';
    Usuario.findById(usuarioID, (err, usuario) => {
      if (err) {
        return res.status(500).send({message: 'Error al intentar obtener el usuario. (status:500)'})
      }else{
        if (!usuario) {
          return res.status(404).send({message: 'El usuario no existe en la base de datos. (status:404)'})
        }else{
          res.json(usuario)
        }
      }
    })
  })

  //Metodo iniciar sesión
  Router.post('/login', function(req, res) {
    const inUser = req.body.user,
        inPassword = req.body.password,
        inSesion = req.session
    Usuario.find({user: inUser}, function (err, busqueda_user) {
      if (err) {
        return res.status(500).send({message: 'Error al intentar obtener el usuario en el inicio de sesión. (status:500)'})
      }else{
        if(busqueda_user.length == 1){
          Usuario.find({user: inUser, password: inPassword}, function (err, busqueda_password) {
            if (err) {
              return res.status(500).send({message: 'Error al intentar obtener el usuario en el inicio de sesión. (status:500)'})
            }else{
              if(busqueda_password.length == 1){
                inSesion.usuario = busqueda_password[0]["user"]
                inSesion.id_usuario = busqueda_password[0]["_id"]
                res.send('OK')
              }else{
                res.send("La Contraseña insertada es  incorrecta")
              }
            }
          })
        }else{
          res.send("El usuario que ha ingresado no esta registrado")
        }
      }
    });
  })

  //Metodo cerrar sesión
  Router.post('/logout', function(req, res) {
    req.session.destroy(function(err) {
      if (err) {
        return res.status(500).send({message: 'Error al intentar cerrar la sesión. (status:500)'})
      }else{
        req.session = null
        res.send('logout')
        res.end()
      }
    })
  })

  Router.all('/', function(req, res) {
    return res.send({message: 'Error al intentar mostrar el recurso solicitado.'}).end()
  })


//Exportar el modulo
module.exports = Router
