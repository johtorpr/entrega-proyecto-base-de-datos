
const Router = require('express').Router(),
      Usuario = require('../modelo/usuario')


  //Se verifica y crea usuarios del sistema
  Router.get('/verificar_usuarios', function(req, res) {
    Usuario.find({}, (err, usuarios) => {
      if (err) {
        return res.status(500).send({message: 'Se ha producido un error al tratar de obtener los usuarios solicitados. (status:500)'})
      }else{
        if (usuarios.length <= 0) {

			// Se insertan los usuarios al sistema
			const NuevoUsuario = new Usuario()
			NuevoUsuario.user = 'admin'
			NuevoUsuario.password = 'admin'
			NuevoUsuario.save((err, usuario1) => {
			  	if (err) return res.status(500).send({message: 'Se ha producido un error al tratar de insertar el primer usuario. (status:500)'})
			})


			const NuevoUsuarioUno = new Usuario()
			NuevoUsuarioUno.user = 'adminest'
			NuevoUsuarioUno.password = 'adminest'
			NuevoUsuarioUno.save((err, usuario2) => {
			  	if (err) return res.status(500).send({message: 'Se ha producido un error al intentar insertar el segundo usuario. (status:500)'})
			})
        }else{
          return res.json(usuarios)
        }
      }
    })
  })



module.exports = Router
