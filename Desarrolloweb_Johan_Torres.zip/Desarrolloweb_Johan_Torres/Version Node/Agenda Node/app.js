//Montar Rutas, servir archivos estaticos y requerir modulos
const 	express = require('express'),
		bodyParser = require('body-parser'),
		session = require('express-session'),
		RutaUsuarios = require('./Controlador/usuario'),
		RutaCrearUsuarios = require('./Controlador/crear_usuario'),
		RutaEventos = require('./Controlador/evento'),
		app = express()


app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: false}))
//Se sirven los archivos estaticos en la carpeta vista
app.use('/', express.static(__dirname + '/vista'));


//Este es el manejador de sesion de usuarios
app.use(session({
	secret: 'clave_johan_torres_156',
	cookie: {maxAge: 36000000},
	resave: false,
	saveUninitialized: true
}));


//Se montan las rutas del controlador
app.use('/usuarios', RutaUsuarios)
app.use('/usuarios', RutaCrearUsuarios)
app.use('/eventos', RutaEventos)



module.exports = app
