//crear y exportar esquema usuario
var mongoose = require('mongoose'),
		esquema = mongoose.Schema


var	SchemaUser = new esquema({
	user: {type: String, unique: true, lowercase: true},
	password: {type: String, required: true, lowercase: true}
})

//////////////////////////////////////
module.exports = mongoose.model('Usuario', SchemaUser)
