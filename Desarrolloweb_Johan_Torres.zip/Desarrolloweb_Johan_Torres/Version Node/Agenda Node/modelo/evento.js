//Se crea y se exporta el esquema para el modelo
const mongoose = require('mongoose'),
				Schema = mongoose.Schema

var	SchemaEvent = new Schema({
	id_usuario: {type: Schema.ObjectId, ref: "Usuario" },
	title: {type: String, required: true},
	start: {type: String, required: true},
	end: {type: String, required: false}
})

module.exports = mongoose.model('Evento', SchemaEvent)
///////////////////////////////////////////////////////////
