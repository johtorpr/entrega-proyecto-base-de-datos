
//Funcion para crear Usuarios del sistema en el caso de que No existan
function verificarExistenciaDeUsuarios() {
    $.ajax({
        url: '/usuarios/verificar_usuarios',
        method: 'GET',
        data: {},
        success: function(res) {
            mensaje = "";
            for (var i=0; i<res.length; i++) {
                mensaje += '<small>Usuario: '+res[i].user+' - Clave: '+res[i].password+'</small><br>';
            }
            $('#mensajeUsuarios').html(mensaje);
        }
    })
}

//Funcion para validar inicio de sesión
function validarUsuario() {
    var userDeUsuario = $('#user');
    var passwordDeUsuario = $('#pass');
    if (userDeUsuario.val() != "" && passwordDeUsuario.val() != "") {
        $.ajax({
            url: '/usuarios/login',
            method: 'POST',
            data: {
                user: userDeUsuario.val(),
                password: passwordDeUsuario.val()
            },
            success: function(res) {
                mostrarMensaje(res);
                if (res == "OK") {
                    window.location.href = "http://localhost:3000/main.html";
                }
            }
        })
    } else {
        alert("Por favor complete todos los campos del formulario");
    }
}

function mostrarMensaje(msj){
    $('#mensajeSesion').html(msj);
}
