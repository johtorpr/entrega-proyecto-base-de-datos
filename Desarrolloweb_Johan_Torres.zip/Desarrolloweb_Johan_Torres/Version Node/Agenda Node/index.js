//Se realiza conexion a la BD y al servidor
const http = require('http'),
express = require('express'),
		mongoose = require('mongoose'),
		app = require('./app'),
		port = process.env.PORT || 3000



mongoose.connect('mongodb://localhost:27017/Agenda_nodejs', {useMongoClient: true})
var db = mongoose.connection

db.on('error', function(err){
  console.log('Conexion error', err)
})

db.once('open', function(){
  console.log('Conectado exitosamente a la base de datos')
})

	const Server = http.createServer(app)
	Server.listen(port, function() {
  		console.log('El servidor se esta ejecutando en la rura: http://localhost:'+ port)
	})
//})
