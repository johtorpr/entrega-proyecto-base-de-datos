Agenda PHP
1. Ejecute su servidor local
2. restaure o importe la base de datos agenda_db.sql
3. copie el proyecto dentro de la carpeta publica del servidor
4. ejecute el archivo index.PHP
5. Ingrese con los usuarios definidos en el sistema para ingresar "user: usuario@mail.com" password: 12342. 
